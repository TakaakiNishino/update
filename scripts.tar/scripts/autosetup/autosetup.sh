#!/bin/bash


# Waiting for network connect ==========================================="

while :
 do
  ping -c 1 www.baidu.com > /dev/null 2>&1
  if [ $? -ne 0 ]; then
   echo "Waiting for Net connect...\n"
   sleep 10
 else
   break
 fi
done

##Get MAC & IP address (Rpi4 only) ====================================="
#BOX
MACADDR=`ifconfig | grep -e 'dc:a6:32' -e 'e4:5f:01'  | awk '{print substr($2, index($1, "ether"))}'`
#VIEW
#MACADDR=`ifconfig | grep -e 'dc:a6:32' -e 'e4:5f:01'  | awk '{print substr($2, index($1, "ether"))}' | sed 's/:/-/g'`
#IoTF
#MACADDR=`cat /home/pi/pi-tour-device/.env | grep -e 'DEVICE_ID=' | sed 's/DEVICE_ID=//g'`
IPADDR=`ifconfig | grep '192.168.' -m 1 | awk '{print $2}'`
LOGFILE=`echo "${MACADDR}" | sed 's/:/-/g'`"_setup.log"
sudo rm $LOGFILE
echo "Setup Log #################################################################" >>$LOGFILE 2>>$LOGFILE
echo "Get MAC & IP address (Rpi4 only) =====================================" >>$LOGFILE 2>>$LOGFILE
echo "MAC: ${MACADDR} IP:${IPADDR}\n" >>$LOGFILE 2>>$LOGFILE
echo "Start setup....: \n" >>$LOGFILE 2>>$LOGFILE

echo "Send message (Starting) =====================================" >>$LOGFILE 2>>$LOGFILE
MESSAGE="Step1: ${MACADDR} (IP=${IPADDR}) Creating TSUNAGATE-BOX(Nikken-Env, Wi-Fi auto-detect), Please Wait." >>$LOGFILE 2>>$LOGFILE
sudo python /home/pi/scripts/autosetup/slack.py $MESSAGE

echo "Format USB =====================================" >>$LOGFILE 2>>$LOGFILE

COUNT1=0
PN=0
TYPE="null"

while [ $PN -ne "36" ] || [ "$TYPE" != "ext4" ]
do
   echo "Start USB Format....: \n" >>$LOGFILE 2>>$LOGFILE

   sudo umount /mnt/usb   >>$LOGFILE 2>>$LOGFILE
   sudo umount /media/pi/*   >>$LOGFILE 2>>$LOGFILE

   expect -c "
     spawn /home/pi/scripts/autosetup/step1.sh
     expect {
       \"Yes/No?\" {
           send \"Yes\n\"
           exp_continue
       }
       \"Proceed anyway? (y,N)\" {
           send \"y\n\"
           exp_continue
       }
       \"Do you want to continue?\" {
           send \"y\n\"
           exp_continue
       }
       \"Is this still acceptable to you?\" {
           send \"y\n\"
           exp_continue
       }
     }
   "  >>$LOGFILE 2>>$LOGFILE
   echo "\n" >>$LOGFILE 2>>$LOGFILE

   expect -c "
     spawn /home/pi/scripts/autosetup/step2.sh
     expect {
       \"Yes/No?\" {
           send \"Yes\n\"
           exp_continue
       }
       \"Proceed anyway? (y,N)\" {
           send \"y\n\"
           exp_continue
       }
       \"Do you want to continue?\" {
           send \"y\n\"
           exp_continue
       }
       \"Is this still acceptable to you?\" {
           send \"y\n\"
           exp_continue
       }
     }
   "  >>$LOGFILE 2>>$LOGFILE
   echo "\n" >>$LOGFILE 2>>$LOGFILE

   expect -c "
     spawn /home/pi/scripts/autosetup/step3.sh
     expect {
       \"Yes/No?\" {
           send \"Yes\n\"
           exp_continue
       }
       \"Proceed anyway? (y,N)\" {
           send \"y\n\"
           exp_continue
       }
       \"Do you want to continue?\" {
           send \"y\n\"
           exp_continue
       }
       \"Is this still acceptable to you?\" {
           send \"y\n\"
           exp_continue
       }
     }
   "  >>$LOGFILE 2>>$LOGFILE
   echo "\n" >>$LOGFILE 2>>$LOGFILE


   partuuid=`sudo blkid | grep '/dev/sda1' | awk '{print substr($0, index($0, "PARTUUID="))}'`
   partuuid=`echo "${partuuid#*=}" | sed 's/"//g' | sed 's/TYPE=ext4//g'`
   PN=`echo -n $partuuid | wc -m`
   TYPE=`sudo blkid | grep '/dev/sda1' | awk '{print substr($0, index($0, "TYPE="))}' | awk '{print $1}' | sed 's/TYPE=//g' | sed 's/"//g' `
   echo "PARTUUID = $partuuid"  >>$LOGFILE 2>>$LOGFILE
   echo "Format type  = $TYPE"  >>$LOGFILE 2>>$LOGFILE

   if [ 5 -lt $COUNT1 ]; then
      echo "Timed out! \n"  >>$LOGFILE 2>>$LOGFILE
      MESSAGE="Step1: ${MACADDR} (IP=${IPADDR}) USB formating error! Now retrying.. Wait.\n"  >>$LOGFILE 2>>$LOGFILE
      sudo python /home/pi/scripts/autosetup/slack.py $MESSAGE
      umount /media/pi/*
      sudo reboot
   fi
   echo "COUNT1 = $COUNT1 \n"  >>$LOGFILE 2>>$LOGFILE
   COUNT1=`expr $COUNT1 + 1` >>$LOGFILE 2>>$LOGFILE

done
echo "USB format done. \n"  >>$LOGFILE 2>>$LOGFILE

echo "Set Overlay  =====================================" >>$LOGFILE 2>>$LOGFILE

echo "Setting initramfs... \n"  >>$LOGFILE 2>>$LOGFILE
sudo echo "PARTUUID=$partuuid /mnt/usb ext4 defaults,nofail 0 0" >> /etc/fstab
sudo echo "initramfs init.gz" >> /boot/config.txt

echo "Create USB Data ====================================="  >>$LOGFILE 2>>$LOGFILE
sudo mount /dev/sda1 /mnt/usb  >>$LOGFILE 2>>$LOGFILE
sudo cp -r /home/pi/raspi-iot/initial_config/* /mnt/usb/  >>$LOGFILE 2>>$LOGFILE

echo "Expand rootfs ====================================="  >>$LOGFILE 2>>$LOGFILE
sudo raspi-config --expand-rootfs   >>$LOGFILE 2>>$LOGFILE


echo "Get certificates ====================================="  >>$LOGFILE 2>>$LOGFILE
sudo sh /home/pi/scripts/autosetup/create-device-certificates.sh
#sudo sh /home/pi/scripts/autosetup/create-device-certificates-nikken.sh >>$LOGFILE 2>>$LOGFILE

echo "Set Monit ====================================="  >>$LOGFILE 2>>$LOGFILE
echo "et MAC to .env of scripts & monit... \n"  >>$LOGFILE 2>>$LOGFILE
sudo sed -i -e "/DEVICENAME/s/\([a-z0-9:]\{17\}\)/${MACADDR}/g" /home/pi/scripts/.env
sudo sed -i -e "/MONIT_HOST/s/\([a-z0-9:]\{17\}\)/${MACADDR}/g" /home/pi/scripts/monit/.env
sudo touch /mnt/usb/flag

echo "Enable services ====================================="  >>$LOGFILE 2>>$LOGFILE
sudo systemctl enable create_ap.service >>$LOGFILE 2>>$LOGFILE
sudo systemctl enable iot.service >>$LOGFILE 2>>$LOGFILE
sudo systemctl enable monit.service >>$LOGFILE 2>>$LOGFILE
sudo cp /home/pi/scripts/autosetup/90-rc-s320.rules /etc/udev/rules.d/ 

echo "Disnable setup services ====================================="  >>$LOGFILE 2>>$LOGFILE
sudo systemctl disable autosetup.service >>$LOGFILE 2>>$LOGFILE


echo "Send message (Ending) ====================================="  >>$LOGFILE 2>>$LOGFILE
MESSAGE="Step2: ${MACADDR} (IP=${IPADDR}, PARTUUID=$partuuid) Created. Prease check in Web-system. "  >>$LOGFILE 2>>$LOGFILE
sudo python3 /home/pi/scripts/autosetup/slack.py $MESSAGE >>$LOGFILE 2>>$LOGFILE
sudo python /home/pi/scripts/autosetup/slack-logfile.py $LOGFILE >>$LOGFILE 2>>$LOGFILE

#Reboot ====================================="
sudo reboot

#exit 0
