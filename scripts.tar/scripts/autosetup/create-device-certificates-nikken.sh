#!/bin/bash

echo "======================================================"
echo "======== Creating certificates for IoT Device ========"
echo "======================================================"

echo "Installing mosquito client"
sudo apt-get install python-pip mosquitto mosquitto-clients -y

CLIENT_ID=`ip link show eth0 | grep link/ether | awk '{print $2}'`

echo -n 'Creating /home/pi/.cert...'
mkdir -p /home/pi/.cert

openssl genrsa -out /home/pi/.cert/deviceCert.key 2048

openssl req -new -key /home/pi/.cert/deviceCert.key -out /home/pi/.cert/deviceCert.csr \
    -subj "/CN=$CLIENT_ID"

openssl x509 -req -in /home/pi/.cert/deviceCert.csr -CA /home/pi/.cert-nikken/caCertificate.pem \
    -CAkey /home/pi/.cert-nikken/caCertificate.key \
    -CAcreateserial \
    -out /home/pi/.cert/deviceCert.crt -days 36500 -sha256

cat /home/pi/.cert/deviceCert.crt /home/pi/.cert-nikken/caCertificate.pem > /home/pi/.cert/deviceCertAndCACert.crt

#echo "Downloading root cert..."
# wget "https://www.websecurity.digicert.com/content/dam/websitesecurity/digitalassets/desktop/pdfs/roots/VeriSign-Class%203-Public-Primary-Certification-Authority-G5.pem" -O /home/pi/.cert/rootCA.pem
cp /home/pi/.cert-nikken/rootCA.pem /home/pi/.cert/rootCA.pem


echo "Checking AWS IoT endpoint..."

#Nikken
ENDPOINT='a1w2uwubhcnvb-ats.iot.ap-northeast-1.amazonaws.com'
#Takenaka classic
#ENDPOINT='aspr5v6ox24ss-ats.iot.ap-northeast-1.amazonaws.com'

echo "Connecting..."

mosquitto_pub \
    --cafile /home/pi/.cert/rootCA.pem \
    --cert /home/pi/.cert/deviceCertAndCACert.crt \
    --key /home/pi/.cert/deviceCert.key -h $ENDPOINT -p 8883 \
    -q 1 -t device/connect -i $CLIENT_ID \
    --tls-version tlsv1.2 -m "Hello" -d

echo "Device as disonnected to process the registration (JITR). Trying to reconnect now registered..."

for i in {1..10}; do
    sleep 3

    mosquitto_pub \
        --cafile /home/pi/.cert/rootCA.pem \
        --cert /home/pi/.cert/deviceCertAndCACert.crt \
        --key /home/pi/.cert/deviceCert.key \
        -h $ENDPOINT -p 8883 \
        -q 1 -t device/connect -i $CLIENT_ID \
        --tls-version tlsv1.2 -m "Hello" -d
done

echo "================================================================"
echo "=================== Setting up complete! ===================="
echo "================================================================"
