#!/usr/bin/python
#coding: utf-8
import sys
import slackweb
import requests

#print sys.argv[1]

url = "https://slack.com/api/files.upload"
data = {
   "token": "xoxb-1235894467011-3126789017670-Ji5NS8sw8U8kceuSMXVuq0dc",
   "channels": "D033GQRETT9",
   "initial_comment": ""
}

files = {'file': open(sys.argv[1], 'rb')}
requests.post(url, data=data, files=files)
