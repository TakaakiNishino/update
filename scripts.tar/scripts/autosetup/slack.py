#!/usr/bin/python
#coding: utf-8

import slackweb
import sys

slack = slackweb.Slack(url="https://hooks.slack.com/services/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")
slack.notify(text=sys.argv[1] +" "+ sys.argv[2] +" "+ sys.argv[3] +" "+ sys.argv[4] +" "+ sys.argv[5] +" "+ sys.argv[6]+" "+ sys.argv[7]+" "+ sys.argv[8]+" "+ sys.argv[9])
#
