#!/bin/bash
sudo parted /dev/sda mklabel gpt
exit 0
