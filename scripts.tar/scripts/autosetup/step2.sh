#!/bin/bash
sudo parted /dev/sda mkpart primary 0% 100%
exit 0
