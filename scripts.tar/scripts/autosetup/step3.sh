#!/bin/bash
sudo mkfs.ext4 /dev/sda1
exit 0
