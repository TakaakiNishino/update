#!/root/.pyenv/shims/python
#coding: utf-8
import slackweb
import sys
import json
import os
import datetime
import subprocess


# Set argment & env
args = sys.argv
mdesc = args[2]
mhost  = subprocess.run("sudo ifconfig | grep -e 'dc:a6:32' -e 'e4:5f:01'  | awk '{print substr($2, index($1, \"ether\"))}'", shell=True, capture_output=True, check=True).stdout.decode('utf-8')
mservice = args[1]
murl = "https://hooks.slack.com/services/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"

if __name__ == "__main__":

  # set script attributes
  surl = murl
  curDate = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
  colorAlert = "#ff0000"
  colorRecover = "#008000"

  if 'not running' in mdesc or 'failed' in mdesc or 'error' in mdesc:
    titleText = "[" + curDate + "] " + mhost + " - " + mservice
    color = colorAlert
    descMessage = mservice + " " + mdesc 
  else:
    titleText = "[" + curDate + "] " + mhost + " - " + mservice
    color = colorRecover
    descMessage = mservice + " " + mdesc

  slack = slackweb.Slack(url=surl)
  slack.notify(
#     text=titleText,
     attachments = [{
         "fields": [{
             "title": titleText,
             "value": descMessage,
         }],
     }]
  )
