#!/root/.pyenv/shims/python
#coding: utf-8
import slackweb
import sys
import urllib.request
import json
import os
import datetime
import logging
from dotenv import load_dotenv
import subprocess

# load .env file
load_dotenv()

# Logging settings
formatter = '%(levelname)s : %(asctime)s : %(message)s'
logdir = os.path.dirname(os.path.abspath(__file__))
logfile = logdir + "/log/logger.log"
logging.basicConfig(filename=logfile, level=logging.DEBUG, format=formatter)

# Light status
# subprocess.call("sudo python3 /home/pi/raspi-iot/src/bin/i2c.py 6", shell=True)
# logging attributes
logging.debug("==================== START ====================")
logging.debug("Slack notification script started.")
logging.debug("MOINT_HOST         : " + os.getenv('MONIT_HOST'))
logging.debug("MOINT_SERVICE      : " + os.getenv('MONIT_SERVICE'))
logging.debug("MOINT_DESCRIPTION  : " + os.getenv('MONIT_DESCRIPTION'))

if __name__ == "__main__":

  # set script attributes
  surl = os.getenv('SLACK_URL')
  schannel = os.getenv('SLACK_CHANNEL')
  suser = os.getenv('SLACK_USER')
  sicon = os.getenv('SLACK_ICON')
  mhost = os.getenv('MONIT_HOST')
  mservice = os.getenv('MONIT_SERVICE')
  mdesc = os.getenv('MONIT_DESCRIPTION')
  curDate = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
  colorAlert = "#ff0000"
  colorRecover = "#008000"

  if 'not running' in mdesc or 'failed' in mdesc or 'resource limit' in mdesc:
    titleText = "[" + curDate + "] " + mhost + " - " + mservice
    color = colorAlert
    descMessage = mservice + " " + mdesc # + "\n i2c Status：" + get_i2c
  else:
    titleText = "[" + curDate + "] " + mhost + " - " + mservice
    color = colorRecover
    descMessage = mservice + " " + mdesc

  # Set context to Slack webhook notification format.
  data = {
    "channel" : schannel,
    "username" : suser,
    "iconi_emoji" : sicon,
  }
  data['text'] = titleText
  data['attachments'] = []
  data['attachments'].append({})
  data['attachments'][0]['color'] = color
  data['attachments'][0]['fields'] = []
  data['attachments'][0]['fields'].append({})
  data['attachments'][0]['fields'][0]['title'] = "Monit Alert on " + mhost
  data['attachments'][0]['fields'][0]['value'] = descMessage
  logging.debug("WEBHOOK_DATA : " + str(data))

  headers = {
    'Content-Type': 'application/json'
  }

  req = urllib.request.Request(surl, json.dumps(data).encode(), headers)
  with urllib.request.urlopen(req) as res:
    result = res.read()
    logging.debug("request sent to " + surl)
    logging.debug("result : " + str(result))

  logging.debug("==================== END ====================")
