import paho.mqtt.client as mqtt
import subprocess
import json
import sys


def main():
    mainprocess ="box"    # "iot" or "view"
    host = '192.168.1.144'
    port = 1883
    topic = 'monitor/'
    data = get_status(mainprocess)
    print("data= ",data)
    payload = json.dumps(data)
    client = mqtt.Client(protocol=mqtt.MQTTv311)
    client.connect(host, port=port, keepalive=60)
    client.publish(topic, payload)
    client.disconnect()
    return


def get_status(mainprocess):
    print("mainprocess=",mainprocess)
    status_subprocess = subprocess.run("sudo sh /home/pi/scripts/monitor_client/client_subprocess.sh "+ mainprocess, shell=True, stdout=subprocess.PIPE, check=True).stdout.decode().strip().split(",")
#    print("status_subprocess= ",status_subprocess)
    if mainprocess == "box":
        status = {
        "MAC" : status_subprocess[0],
        "IP" : status_subprocess[1],   #chr
        "OVERLAY" : 1 if "overlay" in status_subprocess[2] else 0,  #bool/err
        "CAP_RO" :status_subprocess[3],  #chr
        "CAP_RW" :status_subprocess[4],  #chr
        "USBMNT" : 0 if status_subprocess[5]==None else 1, #boll
        "CAP_USB" :status_subprocess[5], #chr
        "UPTIME" :status_subprocess[6],  #chr
        "LOAD" :status_subprocess[7],  #chr
        "MEMORY" :status_subprocess[8],   #chr
        "SWAP" :status_subprocess[9],   #chr
        "TEMP" :status_subprocess[10],  #chr
        "SERVICE" : 1 if "active" in status_subprocess[13] else 0,  #bool/err
        "WIFI" : 1 if "active" in status_subprocess[14] else 0,  #bool/err
        "DHCPCD" : 1 if "active" in status_subprocess[11] else 0,  #bool/err
        "MONIT" : 1 if "active" in status_subprocess[12] else 0,  #bool/err
        "ENV" : envget(status_subprocess[16]),  #chr
        "VERSION" :status_subprocess[17],  #chr
        "L_REMOTE" :gstate_light(status_subprocess[18])[0], #bool/err
        "L_STATE7" :gstate_light(status_subprocess[18])[1],  #bool/err
        "L_STATE8" :gstate_light(status_subprocess[18])[2],  #bool/err
        "L_SCHEDULE" : 1 if "cron" in status_subprocess[15] else 0
        }

    if mainprocess == "view":
        status = {
        "MAC" : status_subprocess[0],
        "IP" : status_subprocess[1],   #chr
        "OVERLAY" : 1 if "overlay" in status_subprocess[2] else 0,  #bool/err
        "CAP_RO" :status_subprocess[3],  #chr
        "CAP_RW" :status_subprocess[4],  #chr
        "USBMNT" : 0 if status_subprocess[5]==None else 1, #boll
        "CAP_USB" :status_subprocess[5], #chr
        "UPTIME" :status_subprocess[6],  #chr
        "LOAD" :status_subprocess[7],  #chr
        "MEMORY" :status_subprocess[8],   #chr
        "SWAP" :status_subprocess[9],   #chr
        "TEMP" :status_subprocess[10],  #chr
        "SERVICE" :status_subprocess[13],  #chr
        "DHCPCD" :status_subprocess[11],    #bool/err
        "MONIT" :status_subprocess[12],    #bool/err
        "NGINX" :status_subprocess[14],    #bool/err
        "ENV" : envget(status_subprocess[15]),  #chr
        "VERSION" :status_subprocess[16],  #chr
        }
    return status

def gstate_light(status_str):
    if "0x00" in status_str:
        remote = 1
        status7 = 0
        status8 = 0
    elif "0x20" in status_str:
        remote = 1
        status7 = 1
        status8 = 0
    elif "0x40" in status_str:
        remote = 1
        status7 = 0
        status8 = 1
    elif "0x60" in status_str:
        remote = 1
        status7 = 1
        status8 = 1
    elif "0x68" in status_str:
        remote = 0
        status7 = 1
        status8 = 1
    else:
        remote = 2
        status7 = 2
        status8 = 2
    return remote,status7,status8,

def envget(envtxt): 
    if "aspr5v6ox24ss-ats.iot.ap-northeast-1.amazonaws.com" in envtxt:
        env = 1 #nikken
    elif "a1w2uwubhcnvb-ats.iot.ap-northeast-1.amazonaws.com" in envtxt:
        env = 2 #classic
    elif "a1puyebz8zw84e-ats.iot.ap-northeast-1.amazonaws.com" in envtxt:
        env = 3 #iotf
    else:
        env = 0 #Error
    return env

if __name__ == "__main__": 
    main()




