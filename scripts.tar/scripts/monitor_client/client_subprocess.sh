#!/bin/bash

# common 13 Output
mac=`ifconfig | grep -e 'dc:a6:32' -e 'e4:5f:01' -e 'd8:3a:dd'  | awk '{print substr($2, index($1, 'ether'))}'  | tr -d '\n'`
ip=`ifconfig | grep '192.168.' -m 1 | awk '{print $2}' | tr -d '\n'`
overlaytxt=`sudo df -h | grep 'overlay' | awk '{print $1}' | tr -d '\n'`
cap_ro=`sudo df -h | grep 'root-ro' | awk '{print $4}' | tr -d '\n'`
cap_rw=`sudo df -h | grep -e '/dev/root' -e '/mnt/root-rw' | awk '{print $4}' | tr -d '\n'`
cap_usb=`sudo df -h | grep '/mnt/usb' | awk '{print $4}' | tr -d '\n'`
NUM=`uptime | wc -w`
if [ $NUM = 10 ];then
uptime=`sudo uptime | awk '{print $3}' | tr -d "," | tr -d '\n'`
load=`sudo uptime | awk '{print $8}' | tr -d "," | tr -d '\n'`
elif [ $NUM = 12 ];then
uptime=`sudo uptime | awk '{print $3}' | tr -d "," | tr -d '\n'`day
load=`sudo uptime | awk '{print $10}' | tr -d "," | tr -d '\n'`
else
uptime="0"
load="0"
fi
memory=`free -gh | grep 'Mem' | awk '{print $4}' | tr -d '\n'`
swap=`free -gh | grep 'Swap' | awk '{print $4}' | tr -d '\n'`
temp=`vcgencmd measure_temp | sed 's/temp=//g' | tr -d "'C"`
dhcpcd=`sudo systemctl status dhcpcd.service | grep 'Active' | awk '{print $2}'`
monit=`sudo systemctl status monit.service | grep 'Active' | awk '{print $2}'`

if [ $1 = box ];then
    # Box 5 output
    service=`sudo systemctl status iot.service | grep "Active" | awk '{print $2}'`
    wifi=`sudo systemctl status create_ap.service | grep "Active" | awk '{print $2}'`
    cron=`sudo cat /var/spool/cron/crontabs/root | grep -v "#"`
    envtxt=`sudo cat /home/pi/raspi-iot/.env | grep "IOT_HOST" | grep -v "#" | sed "s/IOT_HOST=//g" `
    version=`sudo cat /home/pi/raspi-iot/src/helpers/config.js | grep "CONFIG.version" | grep -v "#" | sed "s/CONFIG.version = //g" | sed -e "s/'//g" | sed -e "s/;//g"`
    light=`sudo python3 /home/pi/raspi-iot/src/bin/get_i2c.py`
    echo $mac,$ip,$overlaytxt,$cap_ro,$cap_rw,$cap_usb,$uptime,$load,$memory,$swap,$temp,$dhcpcd,$monit,$service,$wifi,$cron,$envtxt,$version,$light
    #19 output
fi

if [ $1 = view ];then
    # VIEW 4 output
    service=`sudo systemctl status pi-tour-device.service | grep "Active" | awk '{print $2}' `
    nginx=`sudo systemctl status nginx.service | grep "Active" | awk '{print $2}'`
    envtxt=`sudo cat /home/pi/pi-tour-device/.env | grep "IOT_HOST" | grep -v "#" | sed "s/IOT_HOST=//g" `
    version=`sudo cat /home/pi/pi-tour-device/src/helpers/config.js | grep "CONFIG.version" | grep -v "#" | sed "s/CONFIG.version = //g" | sed -e "s/'//g" | sed -e "s/;//g"`
    echo $mac,$ip,$overlaytxt,$cap_ro,$cap_rw,$cap_usb,$uptime,$load,$memory,$swap,$temp,$dhcpcd,$monit,$service,$nginx,$envtxt,$version
    #17 output
fi
