#!bin/bash
DAY=`date`
TEMP=`vcgencmd measure_temp`
echo $DAY "…" $TEMP 1>> /mnt/usb/logs/cpu-temp.log
