#!/usr/bin/python
#coding: utf-8

import serial
import time
from datetime import datetime
import sys
import slackweb

# LED display rule
DISPLAY_RULE_NORMALLY_OFF = 0
DISPLAY_RULE_NORMALLY_ON = 1
PLACE="技研"

# slack webhook URL
#技研
slack = slackweb.Slack(url="https://hooks.slack.com/services/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")
#展示場-東南
#slack = slackweb.Slack(url="https://hooks.slack.com/services/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")
#展示場-北西
#slack = slackweb.Slack(url="https://hooks.slack.com/services/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")

def s16(value):
    # &＝AND |=OR
    return -(value & 0x8000) | (value & 0x7fff)

def calc_crc(buf, length):
    """
    CRC-16 calculation.
    """
    crc = 0xFFFF
    for i in range(length):
        crc = crc ^ buf[i]
        for i in range(8):
            carrayFlag = crc & 1
            crc = crc >> 1
            if (carrayFlag == 1):
                crc = crc ^ 0xA001
    crcH = crc >> 8
    crcL = crc & 0x00FF
    return (bytearray([crcL, crcH]))

def print_latest_data(data1,data2):
    """
    print measured latest value.
    """

    time_measured = datetime.now().strftime("%m/%d %H:%M")
    temperature = str( s16(int(hex(data1[9]) + '{:02x}'.format(data1[8], 'x'), 16)) / 100)
    relative_humidity = str(int(hex(data1[11]) + '{:02x}'.format(data1[10], 'x'), 16) / 100)
    ambient_light = str(int(hex(data1[13]) + '{:02x}'.format(data1[12], 'x'), 16))
    barometric_pressure = str(int(hex(data1[17]) + '{:02x}'.format(data1[16], 'x') + '{:02x}'.format(data1[15], 'x') + '{:02x}'.format(data1[14], 'x'), 16) / 1000)
    sound_noise = str(int(hex(data1[19]) + '{:02x}'.format(data1[18], 'x'), 16) / 100)
    eTVOC = str(int(hex(data1[21]) + '{:02x}'.format(data1[20], 'x'), 16))
    eCO2 = str(int(hex(data1[23]) + '{:02x}'.format(data1[22], 'x'), 16))
    discomfort_index = str(int(hex(data1[25]) + '{:02x}'.format(data1[24], 'x'), 16) / 100)
    heat_stroke = str(s16(int(hex(data1[27]) + '{:02x}'.format(data1[26], 'x'), 16)) / 100)

    wind_power_v = str(data2[9:15])
    wind_direction_v = str(data2[26:32])

    wind_power_num = float(data2[9:14]) * (70/(3-0.6))-17.5
#    wind_power_num = 0.75 * (70/(3-0.6)) -17.5
    if wind_power_num < 0 :
        wind_power = "error"
    else:
        wind_power = str(wind_power_num)

    wind_direction_num = float(data2[26:31]) * (360/(3-0.6))-90
#    wind_direction_num = 0.75 * (360/(3-0.6)) -90
#    wind_direction = str(wind_direction_num)


    if wind_direction_num >=-1 and wind_direction_num <22.5 :
        wind_direction = "北 "+ str(int(wind_direction_num)) + "[°]"
    elif wind_direction_num >=22.5 and wind_direction_num <67.5 :
        wind_direction = "北東 "+ str(int(wind_direction_num)) + "[°]"
    elif wind_direction_num >=67.5 and wind_direction_num <112.5 :
        wind_direction = "東 "+ str(int(wind_direction_num)) + "[°]"
    elif wind_direction_num >=112.5 and wind_direction_num <157.5 :
        wind_direction = "南東 "+ str(int(wind_direction_num)) + "[°]"
    elif wind_direction_num >=157.5 and wind_direction_num <202.5 :
        wind_direction = "南 "+ str(int(wind_direction_num))  +"[°]"
    elif wind_direction_num >=202.5 and wind_direction_num <247.5 :
        wind_direction = "南西 "+ str(int(wind_direction_num)) + "[°]"
    elif wind_direction_num >=247.5 and wind_direction_num <292.5 :
        wind_direction = "西 "+ str(int(wind_direction_num)) +"[°]"
    elif wind_direction_num >=292.5 and wind_direction_num <337.5 :
        wind_direction = "北西 "+ str(int(wind_direction_num))  +"[°]"
    elif wind_direction_num >=337.5 :
        wind_direction = "北"+ str(int(wind_direction_num)) +"[°]"
    else:
        wind_direction = "error"
    return (time_measured + " " + PLACE + " / 温度[℃]:" + temperature + " / 湿度[%]:" + relative_humidity \
    + " / 照度[Lux]:" + ambient_light  + " / 気圧[hPa]:" + barometric_pressure \
    + " / 騒音[dBA]:" + sound_noise + " / eTVOC[ppmC]:" + eTVOC + " / eCO2[ppm]:" + eCO2 \
    + " / 不快指数:" + discomfort_index + " / 熱中症指数:" + heat_stroke \
#    + " / 風力[V]:" + wind_power_v + " / 風向[V]:" + wind_direction_v \
    + " / 風力[m/s]:" + wind_power + " / 風向:" + wind_direction)

#=====================================================================================
#風力計取り込み＆計算
#=====================================================================================



#=====================================================================================

def now_utc_str():
    """
    Get now utc.
    """
    return datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")


if __name__ == '__main__':

    # Serial.
    ser1 = serial.Serial("/dev/ttyUSB_Sensor", 115200, serial.EIGHTBITS, serial.PARITY_NONE)
    ser2 = serial.Serial("/dev/ttyUSB_ADB", 115200, serial.EIGHTBITS, serial.PARITY_NONE)
    command = bytearray([0x52, 0x42, 0x05, 0x00, 0x01, 0x21, 0x50])
    command = command + calc_crc(command, len(command))
    tmp = ser1.write(command)
    time.sleep(0.1)
    sensor_data = ser1.read(ser1.inWaiting())
    wind_data = ser2.read(33).decode()
    print(wind_data)
    print(ser2.read(33))
#    print(print_latest_data(sensor_data,wind_data))
    print_latest_data(sensor_data,wind_data)
    slack.notify(text=print_latest_data(sensor_data,wind_data))

    """
    try:
        # LED On. Color of Green.
        command = bytearray([0x52, 0x42, 0x0a, 0x00, 0x02, 0x11, 0x51, DISPLAY_RULE_NORMALLY_ON, 0x00, 0, 255, 0])
        command = command + calc_crc(command, len(command))
        ser.write(command)
        time.sleep(0.1)
        ret = ser.read(ser.inWaiting())

        while ser.isOpen():
            # Get Latest data Long.
            command = bytearray([0x52, 0x42, 0x05, 0x00, 0x01, 0x21, 0x50])
            command = command + calc_crc(command, len(command))
            tmp = ser.write(command)
            time.sleep(0.1)
            data = ser.read(ser.inWaiting())
            print_latest_data(data)
            slack.notify(text=print_latest_data(data))

    except KeyboardInterrupt:
        # LED Off.
        command = bytearray([0x52, 0x42, 0x0a, 0x00, 0x02, 0x11, 0x51, DISPLAY_RULE_NORMALLY_OFF, 0x00, 0, 0, 0])
        command = command + calc_crc(command, len(command))
        ser.write(command)
        time.sleep(1)
    """
        # script finish.
    sys.exit
