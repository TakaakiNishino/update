#!/bin/bash

SERVICE=$1
IPADDR=`ifconfig | grep '192.168.' -m 1 | awk '{print $2}'`
CERTFORM=`ls /home/pi/.cert | grep 'dcd-' | sed -n 1p | awk '{print substr($0,1,index($0,"-conn")-1 )}'`
if [ "$CERTFORM" = "" ] ;then
DEVICE=`sudo blkid | grep "/dev/sd" | sed -n 1p | cut -c 1-8`
else
DEVICE=$CERTFORM
fi

if [ "$SERVICE" = "BOX" ];then
LIGHTSTATEDEF=`sudo python3 /home/pi/raspi-iot/src/bin/get_i2c.py`
fi

if [ "$SERVICE" = "BOX" ] && [ "$2" = "-e" ] ;then
HEADMSG="Detected I/O error!"
sudo python3 /home/pi/raspi-iot/src/bin/i2c.py 6
sleep 1
elif [ "$SERVICE" = "BOX" ] && [ "$2" = "-c" ] && [ "$LIGHTSTATEDEF" = "0x00" ] ;then
HEADMSG="Scheduled USB filesystem check is running."
elif [ "$SERVICE" = "VIEW" ] && [ "$2" = "-e" ] ;then
HEADMSG="Detected I/O error!"
elif [ "$SERVICE" = "VIEW" ] && [ "$2" = "-c" ] ;then
HEADMSG="Scheduled USB filesystem check is running."
else
exit
fi

if [ "$SERVICE" = "BOX" ] && [ "$DEVICE" = "" ] ;then
sudo python3 /home/pi/raspi-iot/src/bin/i2c.py 6
sudo touch /mnt/usb/flag
sudo python3 /home/pi/scripts/message/slack-args.py $SERVICE "$IPADDR : USB is completely broken, mount out. Current light status: $LIGHTSTATE "
exit
elif [ "$SERVICE" = "VIEW" ] && [ "$DEVICE" = "" ] ;then
sudo touch /mnt/usb/flag
sudo python3 /home/pi/scripts/message/slack-args.py $SERVICE "$IPADDR : USB is completely broken, mount out."
exit
fi


if [ "$SERVICE" = "BOX" ];then
LIGHTSTATE=`sudo python3 /home/pi/raspi-iot/src/bin/get_i2c.py`
sudo systemctl stop iot.service
sudo umount /mnt/usb/
sudo cp -r /home/pi/raspi-iot/initial_config/* /mnt/usb/
sudo systemctl restart iot.service
sudo python3 /home/pi/scripts/message/slack-args.py $SERVICE "$IPADDR : $HEADMSG Current light status: $LIGHTSTATE . Now chaking USB filesystem, please wait for minuits..."
BADBLOCK=`sudo badblocks -snf $DEVICE`
suod rm /mnt/usb/flag
sudo mount $DEVICE /mnt/usb
sudo systemctl restart iot.service
elif [ "$SERVICE" = "VIEW"];then
sudo systemctl stop pi-tour-device.service
sudo umount /mnt/usb/
sudo cp -r /home/pi/pi-tour-device/initial_config* /mnt/usb/
sudo systemctl restart pi-tour-device.service
sudo python3 /home/pi/scripts/message/slack-args.py $SERVICE "$IPADDR : $HEADMSG Now chaking USB filesystem, please wait for minuits..."
BADBLOCK=`sudo badblocks -snf $DEVICE`
suod rm /mnt/usb/flag
sudo mount $DEVICE /mnt/usb
sudo systemctl restart pi-tour-device.service
fi


if [ "$BADBLOCK" != "" ];then
sudo python3 /home/pi/scripts/message/slack-args.py $SERVICE "USB has been repaird, remounted. Main service has been resterted."
else
sudo python3 /home/pi/scripts/message/slack-args.py $SERVICE "USB is safe, remounted. Main service has been resterted."
fi
