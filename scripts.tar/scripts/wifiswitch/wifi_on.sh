#!/bin/bash

sudo systemctl stop iot.service
sudo sed -i 's/^.*denyinterfaces eth0/denyinterfaces eth0/g' /etc/dhcpcd.conf
sudo sed -i 's/^.*interface br0/interface br0/g' /etc/dhcpcd.conf
sudo umount /mnt/usb
sudo mount -o remount,rw /mnt/root-ro
#sudo mount -o bind /run /mnt/root-ro/run
sudo chroot /mnt/root-ro
sudo sed -i 's/^.*denyinterfaces eth0/denyinterfaces eth0/g' /mnt/root-ro/etc/dhcpcd.conf
sudo sed -i 's/^.*interface br0/interface br0/g' /mnt/root-ro/etc/dhcpcd.conf
sudo mount /dev/sda1 /mnt/usb

sudo ln -s /mnt/root-ro/etc/systemd/system/multi-user.target.wants/create_ap.service /usr/lib/systemd/system/create_ap.service
sudo systemctl enable create_ap.service
sudo systemctl restart dhcpcd.service
sudo systemctl restart create_ap.service
sudo systemctl restart iot.service
